﻿using Microsoft.Playwright;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlTypes;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace PlayWrightDemo
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private async void button1_Click(object sender, EventArgs e)
		{

			IPlaywright playwright = await Playwright.CreateAsync();

			//BrowserTypeLaunchOptions options = new BrowserTypeLaunchOptions();
			///*
			// * 设置PlayWright运行时有/无浏览器UI，默认无
			// * Headless=true,运行速度快，常用于自动化运行
			// * Headless=false，常用于调试代码
			// */
			//options.Headless = false;
			////设置浏览器沙盒模式
			//options.ChromiumSandbox = false;
			///*
			// * 设置浏览器可执行文件路径
			// * Windows：%USERPROFILE%\AppData\Local\ms-playwright
			// * MacOS：~/Library/Caches/ms-playwright
			// * Linux：~/.cache/ms-playwright
			// * 也可设置本机安装的相应浏览器
			// * 调试环境下可不设置，如发布程序浏览器可执行文件发生变动则必须设置；
			// */
			//options.ExecutablePath = @"C:\Users\hanjg\AppData\Local\ms-playwright\chromium-1028\chrome-win\chrome.exe";
			//options.ExecutablePath = @"C:\Program Files\Google\Chrome\Application\chrome.exe";

			//IBrowser browser = await playwright.Chromium.LaunchAsync(options);
			IBrowser browser = await playwright.Chromium.LaunchAsync(new BrowserTypeLaunchOptions()
			{
				Headless = false,
				ChromiumSandbox = false,
				ExecutablePath = @"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
			});

			var context = await browser.NewContextAsync(new BrowserNewContextOptions() { StorageStatePath = "state.json" });
			IPage page = await context.NewPageAsync();
			await page.GotoAsync("http://192.168.30.150/login.aspx");
			string title = await page.TitleAsync();
			Console.WriteLine($"Page title: {title}");
			//await browser.CloseAsync();
		}

		private async void button2_Click(object sender, EventArgs e)
		{
			try
			{
				IPlaywright playwright = await Playwright.CreateAsync();

				BrowserTypeLaunchOptions options = new BrowserTypeLaunchOptions();
				/*
				 * 设置PlayWright运行时有/无浏览器UI，默认无
				 * Headless=true,运行速度快，常用于自动化运行
				 * Headless=false，常用于调试代码
				 */
				options.Headless = false;
				//设置浏览器沙盒模式
				options.ChromiumSandbox = false;

				/*
				 * 设置浏览器可执行文件路径
				 * Windows：%USERPROFILE%\AppData\Local\ms-playwright
				 * MacOS：~/Library/Caches/ms-playwright
				 * Linux：~/.cache/ms-playwright
				 * 也可设置本机安装的相应浏览器
				 * 调试环境下可不设置，如发布程序浏览器可执行文件发生变动则必须设置；
				 */
				options.ExecutablePath = @"C:\Users\hanjg\AppData\Local\ms-playwright\chromium-1028\chrome-win\chrome.exe";
				//options.Args = new List<string>() { "--start-maximized" };
				options.ExecutablePath = @"C:\Program Files\Google\Chrome\Application\chrome.exe";

				IBrowser browser = await playwright.Chromium.LaunchAsync(options);
				//　var context = await browser.NewContextAsync(new BrowserNewContextOptions() { ViewportSize = ViewportSize.NoViewport });
				var context = await browser.NewContextAsync(new BrowserNewContextOptions() { });

				//IPage page = await browser.NewPageAsync();
				IPage page = await context.NewPageAsync();

				//browser.new_context(storage_state = "state.json")
				//var conte = browser.NewContextAsync("");

				await page.GotoAsync("http://192.168.30.150/login.aspx");
				string title = await page.TitleAsync();
				Console.WriteLine($"Page title: {title}");

				//01
				//await page.FillAsync("input[id=\"txtUserNo\"]", "DL15009");
				//await page.FillAsync("input[id=\"txtPassword\"]", "12345678");
				//await page.ClickAsync("input[id=\"btnLogin\"]");

				//02
				//await page.FillAsync("#txtUserNo", "DL15009");
				//await page.FillAsync("#txtPassword", "12345678");
				//await page.ClickAsync("#btnLogin");
				//await page.WaitForTimeoutAsync(3000);
				//await page.ClickAsync("#menuTreet11");

				//03
				//await page.FillAsync("#txtUserNo", "DL15009");
				var userNo = await page.WaitForSelectorAsync("#txtUserNo");
				await userNo.FillAsync("DL15009");

				await page.FillAsync("#txtPassword", "12345678");
				await page.ClickAsync("#btnLogin");
				//await page.WaitForTimeoutAsync(3000);
				await page.ClickAsync("#menuTreet11");

				await page.PauseAsync();


				//	await page.FrameLocator("#iframeMain").Locator("#ctl00_main_dropYear").SelectOptionAsync("2025年");
				var locator = page.FrameLocator("#iframeMain").Locator("#ctl00_main_dropYear");
				await locator.SelectOptionAsync("2024年");

				locator = page.FrameLocator("#iframeMain").Locator("#ctl00_main_dropMonth");
				await locator.SelectOptionAsync("05月");

				locator = page.FrameLocator("#iframeMain").Locator("#ctl00_main_btnSearch");
				await locator.ClickAsync();

				await context.StorageStateAsync(new BrowserContextStorageStateOptions() { Path = "state.json" });
				
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.ToString());
			}

		}

		private void button3_Click(object sender, EventArgs e)
		{
			//int num = 8;
			//num ^= 152;
			//Debug.WriteLine(num);

			//string string_0 = "123";
			//int value;
			//if (string_0.Split(new char[] { '-' }).Length >= 1 && int.TryParse(string_0.Split(new char[] { '-' })[0], out value))
			//{
			//	Debug.WriteLine(string_0);
			//}
		}

		private async void button4_Click(object sender, EventArgs e)
		{
			IPlaywright playwright = await Playwright.CreateAsync();

			IBrowser browser = await playwright.Chromium.LaunchAsync(new BrowserTypeLaunchOptions()
			{
				Headless = false,
				ChromiumSandbox = false,
				ExecutablePath = @"C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
			});

			var context = await browser.NewContextAsync(new BrowserNewContextOptions() { StorageStatePath = "state.json" });
			IPage page = await context.NewPageAsync();
			//page.Mouse.
			string baseUrl = "http://www.xbiquzw.com/81_81797/";
			await page.GotoAsync(baseUrl);

			//await page.PauseAsync();

			var list = await page.QuerySelectorAllAsync("#list a");

			byte[] data = null;
			foreach (var item in list)
			{
				string href = await item.GetAttributeAsync("href");
				string text = await item.InnerTextAsync();
				string title = await item.GetAttributeAsync("title");
				Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
				data = Encoding.GetEncoding("GBK").GetBytes(text);
				text = Encoding.UTF8.GetString(data);

				//data = Encoding.Default.GetBytes(text);
				//text = Encoding.UTF8.GetString(data, 0, data.Length);
				//data = 

				Console.WriteLine(href);
				Console.WriteLine(text);
				Console.WriteLine(title);
				string newUrl = string.Concat(baseUrl, href);

				IPage page2 = await context.NewPageAsync();
				await page2.GotoAsync(newUrl);
				await page2.WaitForLoadStateAsync(LoadState.DOMContentLoaded);

				var txtCtl = await page2.QuerySelectorAsync("#content");
				text = await txtCtl.InnerTextAsync();
				Console.WriteLine(text);
				await page2.WaitForTimeoutAsync(1000);
				
				await page2.CloseAsync();
			}

		}
	}
}
